package org.bookerbuddies.bookease.client;

import org.bookerbuddies.bookease.client.dto.RegisterAccount;

public interface ClientService {
    Client newRegistration(RegisterAccount registerAccount) throws ClientException;
    Client login(String email, String password) throws ClientException;

    Client getClientbyId(Integer clientId)throws ClientException;
}
